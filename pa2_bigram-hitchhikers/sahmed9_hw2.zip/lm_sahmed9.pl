:-['/Users/salee/Documents/hw/cl/bigrams_sahmed9.pl'].
:-['/Users/salee/Documents/hw/cl/unigrams_sahmed9.pl'].

calc_prob(ListOfWords,SmoothedLog10Probability):-
calc_prob(ListOfWords,0,SmoothedLog10Probability).
calc_prob([],N,N).
calc_prob([A],N,N).
calc_prob([W1,W2|L],A,B) :- 
    (bigram(Co,W1,W2); Co is 0),
    (unigram(CU,W1); CU is 0),
    PR is log10((Co + 1)/(CU + 24190))+ A,
    append([W2],L,C),
    calc_prob(C,PR,B).